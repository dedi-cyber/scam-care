# Scam-care

Game simulasi latihan mengenali penipuan digital. Situs statis, tanpa proses build.

## Deploy ke Netlify lewat GitHub

1. Buat repositori GitHub baru, lalu unggah seluruh isi folder ini.
2. Di Netlify: Add new site, Import an existing project, pilih GitHub dan repositori tadi.
3. Build command dikosongkan, Publish directory diisi `.` (sudah diatur di `netlify.toml`).
4. Deploy. Setiap push ke GitHub akan memicu deploy ulang.

## Struktur

- `index.html`: halaman dan logika game
- `assets/`: runtime, React, font, (semua lokal, tanpa CDN)
- `netlify.toml`: header keamanan dan cache

Kemajuan pemain disimpan di localStorage peramban masing-masing.

© @ D.E.A.
